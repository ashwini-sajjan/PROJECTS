# JobPortal
 This is an online job portal website implemented using HTML,CSS,Javascript with the help of bootstrap and jquery.

## Functionalities
  * A disjointed Login and Signup methods for Users and Recruiters.
  * A jobseeker can apply for the posted jobs in the website and he can upload his resume.
  * Recruiter can search the resume and if his requirements meets , he can send the notification to the jobseeker.
