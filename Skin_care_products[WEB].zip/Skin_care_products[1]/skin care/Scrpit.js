// window.addEventListener("load",()=>{
//     const load = document.querySelector(".preloader");
//     load.classList.add("preloaderhidden");

//     // or 
//     // load.style.display="none";
// })

// gsap.to(".navbar",{
//     backgroundColor:"antiquewhite",
//     height:"100px",
//     duration:0.7,
//     scrollTrigger:{
//         trigger:".navbar",
//         scroller:"body",
//         start:"top-10%",
//         scrub:true
//     }

// })
// gsap.from(".card",{
//   y:70,
//   duration:1,
//   opacity:0,
//   stagger:0.6,
//   scrollTrigger:{
//     trigger:".card",
//     scroller:"body",
//     start:"top-160%"
//   }
// })

// gsap.from(".cardd",{
//   y:60,
//   duration:1,
//   opacity:0,
//   stagger:0.7,
//   scrollTrigger:{
//     trigger:".cardd",
//     scroller:"body",
//   }
// })

// gsap.from("#text,.btn", {
//   y:"200",
//   duration: 2.1,
//   opacity:0,
//   ease: "circ"
// })
// gsap.from(".mid,.mid1",{
//   scale:0.9,
//   opacity:0,
//   duration:1,
//   stagger:0.3,
//   scrollTrigger:{
//     trigger:".mid,.mid1",
//     scroller:"body",
//   }
// })
const swiper = new Swiper('.swiper', {
    // Optional parameters
    loop: true,
  
    // If we need pagination
    pagination: {
      el: '.swiper-pagination',
    },
  
    // Navigation arrows
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
  });